
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Stuck In A Time Loop
* Link: https://open.kattis.com/contests/mjt68e/problems/touchscreenkeyboard
* @author: Nguyen Le Hoang Dang
* @version: 2.0, 2022-10-25
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.55s
*/

import java.util.*;

public class touchscreenkeyboard {
    static HashMap<Character, int[]> keyboardCoordSum = new HashMap<>();

    public static int keyboardDist(String lhs, String rhs) {
        int sum = 0;
        for (int i = 0; i < lhs.length(); i++) {
            var lhsval = keyboardCoordSum.get(lhs.charAt(i));
            var lhsx = lhsval[0];
            var lhsy = lhsval[1];
            var rhsval = keyboardCoordSum.get(rhs.charAt(i));
            var rhsx = rhsval[0];
            var rhsy = rhsval[1];
            sum = sum + Math.abs(lhsx - rhsx) + Math.abs(lhsy - rhsy);
        }
        return sum;
    }

    public static void main(String args[]) {
        String[] words = { "qwertyuiop", "asdfghjkl", "zxcvbnm" };
        for (int i = 0; i < words.length; i++) {
            for (int j = 0; j < words[i].length(); j++) {
                keyboardCoordSum.put(words[i].charAt(j), new int[] { i, j });
            }
        }
        int t, l;
        Scanner sc = new Scanner(System.in);
        t = sc.nextInt();
        for (int i = 0; i < t; i++) {
            String word = sc.next();
            l = sc.nextInt();
            ArrayList<String> spellChecker = new ArrayList<String>();
            for (int j = 0; j < l; j++) {
                spellChecker.add(sc.next());
            }
            Collections.sort(spellChecker, (rhs, lhs) -> {
                int cmp = keyboardDist(rhs, word) - keyboardDist(lhs, word);
                if (cmp == 0) {
                    cmp = rhs.compareTo(lhs);
                }
                return cmp;
            });
            for (String checker : spellChecker) {
                System.out.printf("%s %d\n", checker, keyboardDist(checker, word));
            }
        }
        sc.close();
    }
}