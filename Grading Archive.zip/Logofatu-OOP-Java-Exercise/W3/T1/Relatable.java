public interface Relatable {
    public int isLargerThan(Relatable other);
}
