
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Flying Safely
* Link: https://open.kattis.com/contests/uk27ry/problems/flyingsafely
* @author: Duy Vo Nguyen Minh
* @version: 1.0, 2022-11-10
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.62s
*/

import java.util.Scanner;

public class flyingsafely {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int numTest = scan.nextInt();
        for (int i = 0; i < numTest; i++) {
            int cities = scan.nextInt();
            int pilots = scan.nextInt();
            // System.out.println(pilots);
            for (int j = 0; j < pilots; j++) {
                int cityA = scan.nextInt();
                int cityB = scan.nextInt();
            }
            int minPilots = pilots < cities ? pilots : cities - 1;
            System.out.println(minPilots);
        }
        scan.close();
    }
}