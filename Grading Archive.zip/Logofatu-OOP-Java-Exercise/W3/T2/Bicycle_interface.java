public interface Bicycle_interface {

    public void print_bike();

    public void set_cadence(int numberToSet);

    public void set_gear(int numberToSet);

    public void apply_brake(int numberToSet);

    public void speed_up(int numberToSet);

    public void set_height(int numberToSet);
}