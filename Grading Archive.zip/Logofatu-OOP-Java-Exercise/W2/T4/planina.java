
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Planina
* Link: https://open.kattis.com/contests/ggi5da/problems/planina
* @author: Duy Vo Nguyen Minh
* @version: 1.0, 2022-11-01
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.10s
*/

import java.util.Scanner;

public class planina {
    public static int pointsCount(int i) {
        if (i == 0) {
            return 2;
        } else
            return (2 * pointsCount(i - 1) - 1);
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int iterationCount = input.nextInt();
        input.close();
        int result = pointsCount(iterationCount);
        System.out.println(result * result);
    }
}
