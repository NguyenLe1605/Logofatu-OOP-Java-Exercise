
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Paul Eigon
* Link: https://open.kattis.com/contests/ggi5da/problems/pauleigon
* @author: Duy Vo Nguyen Minh
* @version: 1.0, 2022-11-04
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.10s
*/

import java.util.Scanner;

public class pauleigon {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int serveCount = input.nextInt();
        int paulScore = input.nextInt();
        int opponentScore = input.nextInt();

        if (Math.ceil((paulScore + opponentScore) / serveCount) % 2 == 0) {
            System.out.println("paul");
        } else {
            System.out.println("opponent");
        }
        input.close();
    }
}
