
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Quick Estimates
* Link: https://open.kattis.com/contests/ggi5da/problems/quickestimate
* @author: Duy Vo Nguyen Minh
* @version: 1.0, 2022-10-31
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.11s
*/

import java.util.Scanner;

public class quickestimate {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int numTestcase = input.nextInt();
        int digitEachCost[] = new int[numTestcase];
        for (int i = 0; i < numTestcase; i++) {
            String estimatedCost = input.next();
            digitEachCost[i] = estimatedCost.length();
        }
        input.close();
        for (int i = 0; i < numTestcase; i++) {
            System.out.println(digitEachCost[i]);
        }
    }
}
