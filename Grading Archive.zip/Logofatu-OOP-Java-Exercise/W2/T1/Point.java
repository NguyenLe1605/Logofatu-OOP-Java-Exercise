public class Point {
    public int x;
    public int y;

    public Point(int num_1, int num_2) {
        x = num_1;
        y = num_2;
    }

    public void printPoint() {
        System.out.println("(" + x + "," + y + ")");
    }
}
