
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Scaling Recipe
* Link: https://open.kattis.com/contests/tbnznz/problems/scalingrecipe
* @author: Duy Vo Nguyen Minh
* @version: 1.0, 2022-11-14
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.10s
*/

import java.util.Scanner;
import java.util.*;

public class scalingrecipe {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int i = 0;
        int port_made = input.nextInt();
        int port_need = input.nextInt();
        List<Integer> result_list = new ArrayList<Integer>(n);
        double ratio = (double) port_need / (double) port_made;
        while (i < n) {
            int ingredient = input.nextInt();
            double result = (double) ingredient * ratio;
            result_list.add((int) Math.round(result));
            i++;
        }
        i -= i;
        while (i < n) {
            System.out.println(result_list.get(i));
            i++;
        }
        input.close();
    }
}
