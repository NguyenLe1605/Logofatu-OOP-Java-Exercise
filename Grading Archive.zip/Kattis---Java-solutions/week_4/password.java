
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Password Hacking
* Link: https://open.kattis.com/contests/tbnznz/problems/password
* @author: Duy Vo Nguyen Minh
* @version: 2.0, 2022-11-15
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.21s
*/

import java.util.Scanner;
import java.util.Arrays;

public class password {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int testcasesNum = input.nextInt();
        String[] passwordsList = new String[testcasesNum];
        double[] percentagesList = new double[testcasesNum];
        double finalAttempt = 0.0;
        for (int i = 0; i < testcasesNum; i++) {
            passwordsList[i] = input.next();
            percentagesList[i] = input.nextDouble();
        }
        Arrays.sort(percentagesList);
        for (int i = testcasesNum - 1; i >= 0; i--) {
            finalAttempt += percentagesList[i] * (testcasesNum - i);
        }
        System.out.println(finalAttempt);
        input.close();
    }
}
