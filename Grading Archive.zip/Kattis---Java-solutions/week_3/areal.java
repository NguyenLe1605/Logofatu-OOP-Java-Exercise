
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: A Real Challenge
* Link: https://open.kattis.com/contests/uk27ry/problems/areal
* @author: Duy Vo Nguyen Minh
* @version: 1.0, 2022-11-08
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.11s
*/

import java.util.Scanner;

public class areal {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double area = input.nextDouble();
        input.close();
        double perimeter = Math.sqrt(area) * 4;
        System.out.println(perimeter);
    }
}
