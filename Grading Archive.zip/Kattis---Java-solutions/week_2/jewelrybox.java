
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Jewelry Box
* Link: https://open.kattis.com/contests/ggi5da/problems/jewelrybox
* @author: Duy Vo Nguyen Minh
* @version: 1.0, 2022-11-04
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.46s
*/

import java.util.Scanner;

public class jewelrybox {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int testcase = input.nextInt();
        for (int i = 0; i < testcase; i++) {
            int x = input.nextInt();
            int y = input.nextInt();
            double height = (x + y - Math.sqrt(Math.pow(x + y, 2) - 3 * x * y)) / 6;
            System.out.println(height * (x - 2 * height) * (y - 2 * height));
        }
        input.close();
    }
}