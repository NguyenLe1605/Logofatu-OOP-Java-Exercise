
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Pizza Crust
* Link: https://open.kattis.com/contests/ggi5da/problems/pizza2
* @author: Duy Vo Nguyen Minh
* @version: 1.0, 2022-10-31
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.10s
*/

import java.util.Scanner;

public class pizza2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int radianPizza = input.nextInt();
        int radianCrust = input.nextInt();
        input.close();
        float percent = ((float) (radianPizza - radianCrust) * (radianPizza - radianCrust))
                / (radianPizza * radianPizza);
        System.out.println(percent * 100);
    }
}
