
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Grass Seed Inc.
* Link: https://open.kattis.com/contests/ggi5da/problems/grassseed
* @author: Duy Vo Nguyen Minh
* @version: 1.0, 2022-10-31
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.16s
*/

import java.util.Scanner;

public class grassseed {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double seedCostPerMetre = input.nextDouble();
        int numLawn = input.nextInt();
        double sumLawn = 0.0;
        for (int i = 0; i < numLawn; i++) {
            double width = input.nextDouble();
            double length = input.nextDouble();
            sumLawn += width * length;
        }
        input.close();
        sumLawn *= seedCostPerMetre;
        System.out.println(String.format("%.9g%n", sumLawn));
    }
}
