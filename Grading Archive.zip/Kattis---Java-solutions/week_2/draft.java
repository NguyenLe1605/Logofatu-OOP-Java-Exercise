public class draft {
    public static void main(String[] args) {
        String test = "d";
        System.out.println(test.equals("d"));
    }
}
