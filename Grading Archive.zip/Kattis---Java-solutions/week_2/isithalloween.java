
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: IsItHalloween.com
* Link: https://open.kattis.com/contests/ggi5da/problems/isithalloween
* @author: Duy Vo Nguyen Minh
* @version: 1.0, 2022-10-31
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.10s
*/

import java.util.Scanner;

public class isithalloween {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String month = input.next();
        int day = input.nextInt();
        input.close();
        if ((month.equals("OCT") && day == 31) || (month.equals("DEC") && day == 25)) {
            System.out.println("yup");
        } else
            System.out.println("nope");
    }
}