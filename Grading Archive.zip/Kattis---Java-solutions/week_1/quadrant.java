
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Quadrant Selection
* Link: https://open.kattis.com/contests/mjt68e/problems/quadrant
* @author: Duy Vo Nguyen Minh
* @version: 1.0, 2022-10-27
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.09s
*/

import java.util.Scanner;

public class quadrant {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int x = input.nextInt();
        int y = input.nextInt();
        int answer = 0;
        if (x > 0) {
            if (y > 0) {
                answer = 1;
            } else {
                answer = 4;
            }
        } else if (y > 0) {
            answer = 2;
        } else {
            answer = 3;
        }
        System.out.println(answer);
        input.close();
    }
}
