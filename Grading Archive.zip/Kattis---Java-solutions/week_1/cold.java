
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Cold-puter Science
* Link: https://open.kattis.com/contests/mjt68e/problems/cold
* @author: Duy Vo Nguyen Minh
* @version: 1.0, 2022-10-25
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.10s
*/

import java.util.Scanner;

public class cold {
    public static void main(String[] args) {
        Scanner weather = new Scanner(System.in);
        int n;
        int day_below_zero = 0;
        n = weather.nextInt();
        for (int i = 0; i < n; i++) {
            if (weather.nextInt() < 0) {
                day_below_zero++;
            }
        }
        System.out.println("Number of days below zero: " + day_below_zero);
        weather.close();
    }
}