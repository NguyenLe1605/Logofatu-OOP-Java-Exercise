
/**
 * Advanced Object-Oriented Programming with Java, WS 2022
 * Problem: Hello World!
 * Link: https://open.kattis.com/contests/mjt68e/problems/hello
 * 
 * @author: Duy Vo Nguyen Minh
 * @version: 4.0, 2022-10-25
 * 
 *           Method: Ad-Hoc
 *           Status: Accepted
 *           Run-time: 0.06s
 */

public class helloworld {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
