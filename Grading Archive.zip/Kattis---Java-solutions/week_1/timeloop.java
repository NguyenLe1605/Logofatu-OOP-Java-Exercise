
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Stuck In A Time Loop
* Link: https://open.kattis.com/contests/mjt68e/problems/timeloop
* @author: Duy Vo Nguyen Minh
* @version: 2.0, 2022-10-25
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.12s
*/

import java.util.Scanner;

public class timeloop {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int limit = input.nextInt();
        for (int i = 1; i <= limit; i++) {
            System.out.println(i + " Abracadabra");
        }
        input.close();
    }
}
