
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Ladder
* Link: https://open.kattis.com/contests/mjt68e/problems/ladder
* @author: Duy Vo Nguyen Minh
* @version: 2.0, 2022-10-25
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.09s
*/

import java.util.Scanner;

public class ladder {
    public static void main(String[] args) {
        Scanner figure = new Scanner(System.in);
        int height = figure.nextInt();
        int angle = figure.nextInt();
        double ladder = height / Math.sin(Math.toRadians((double) angle));
        System.out.println((int) Math.ceil(ladder));
        figure.close();
    }
}
