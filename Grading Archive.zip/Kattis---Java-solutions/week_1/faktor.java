
/** 
* Advanced Object-Oriented Programming with Java, WS 2022
* Problem: Faktor
* Link: https://open.kattis.com/contests/mjt68e/problems/faktor
* @author: Duy Vo Nguyen Minh
* @version: 1.0, 2022-10-27
* 
* Method: Ad-Hoc
* Status: Accepted
* Run-time: 0.09s
*/

import java.util.Scanner;

public class faktor {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int articles_num = input.nextInt();
        int impact_factor = input.nextInt();
        int cits_count = (articles_num * (impact_factor - 1)) + 1;
        System.out.println(cits_count);
        input.close();
    }
}
